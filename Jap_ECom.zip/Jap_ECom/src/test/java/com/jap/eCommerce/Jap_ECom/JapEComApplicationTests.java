package com.jap.eCommerce.Jap_ECom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JapEComApplicationTests {

	@Test
	void contextLoads() {
	}

}
