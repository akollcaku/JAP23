package com.jap.eCommerce.Jap_ECom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JapEComApplication {

	public static void main(String[] args) {
		SpringApplication.run(JapEComApplication.class, args);
	}

}
